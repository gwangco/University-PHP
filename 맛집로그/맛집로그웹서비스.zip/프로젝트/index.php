<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title>오늘의 맛집로그</title>
   
</head>
<body>
    <header>
        <?php include "header.php";?>
    </header>
    <section class="main-content-area">
    <?php include "main.php"; ?>
    </section>

    <footer>
        <?php include "footer.php";?>
    </footer>
</body>
</html>