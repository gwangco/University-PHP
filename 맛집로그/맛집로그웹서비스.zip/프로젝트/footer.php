<hr>
<footer>
    <p>&copy; 2025 오늘의 맛집로그. All rights reserved.</p>
    <p>광고문의 : kgjcy123@naver.com</p>
</footer>