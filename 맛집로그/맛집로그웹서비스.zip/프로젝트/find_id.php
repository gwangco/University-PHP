<?php
// find_id.php
include_once "db_connect.php"; // 데이터베이스 연결 파일 포함

// 세션이 필요 없는 페이지이므로 session_start()를 호출하지 않습니다.
// 단독으로 실행되는 팝업 창입니다.
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>아이디 목록</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
        .container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 350px; margin: 0 auto; }
        h2 { text-align: center; color: #333; margin-bottom: 20px; }
        ul { list-style: none; padding: 0; max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px; }
        li { padding: 10px; border-bottom: 1px solid #eee; background-color: #f9f9f9; }
        li:last-child { border-bottom: none; }
        p.empty { text-align: center; color: #888; }
        .close-button { display: block; width: 100%; padding: 10px 0; text-align: center; background-color: #6c757d; color: white; border-radius: 4px; text-decoration: none; margin-top: 20px; }
        .close-button:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="container">
        <h2>전체 아이디 목록</h2>
        <ul>
            <?php
            $sql = "SELECT username FROM users ORDER BY username ASC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($row['username']) . "</li>";
                }
            } else {
                echo "<p class='empty'>등록된 아이디가 없습니다.</p>";
            }
            $conn->close();
            ?>
        </ul>
        <a href="javascript:window.close();" class="close-button">창 닫기</a>
    </div>
</body>
</html>