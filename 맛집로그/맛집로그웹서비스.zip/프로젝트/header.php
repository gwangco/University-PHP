<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$imagePath = "/PHP수업/src/part3/프로젝트/uploads/qqq.png";
$altText = "오늘의 맛집로그 로고"; // 이미지에 대한 설명을 담은 대체 텍스트

?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>오늘의 맛집로그</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div id="branding">
                <h1><a href="index.php">
                    <img src="<?php echo $imagePath; ?>" alt="<?php echo $altText; ?>">
                </a></h1>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">홈 (맛집 목록)</a></li>
                    <li><a href="add_form.php">맛집 추가</a></li>
                    <?php if (isset($_SESSION['userid'])): ?>
                        <li><a href="write_form.php">리뷰 작성</a></li>
                        <li><a href="logout.php">로그아웃 (<?= htmlspecialchars($_SESSION['username']) ?> (<?= htmlspecialchars($_SESSION['nickname']) ?>))</a></li>
                        <li><a href="mypage.php">마이페이지</a></li>
                    <?php else: ?>
                        <li><a href="login.php">로그인</a></li>
                        <li><a href="join_form.php">회원가입</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>

        <div class="main-content">
        
        <div class="container">



    <header>



    <div id="branding">



    <link rel="stylesheet" type="text/css" href="css/style.css">