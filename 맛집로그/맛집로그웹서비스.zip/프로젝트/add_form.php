<?php
// header.php 파일 포함 (세션 시작 포함)
include_once "header.php";
// db_connect.php 파일 포함
include_once "db_connect.php";


// 로그인하지 않은 사용자는 접근 불가능
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 맛집을 추가할 수 있습니다.');</script>";
    echo "<script>window.location.href = 'login.php';</script>"; // 로그인 페이지로 리다이렉트
    exit();
}


// 이 부분은 add_process.php에서 처리하므로, 여기서는 폼만 보여줍니다.
?>

<section>
    <h2>새로운 맛집 추가</h2>
    <form action="add_process.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="name">맛집 이름:</label>
            <input type="text" id="name" name="name" required maxlength="100">
        </div>
        <div>
            <label for="address">주소:</label>
            <input type="text" id="address" name="address" required maxlength="255">
        </div>
        <div>
            <label for="cuisine_type">음식 종류:</label>
            <input type="text" id="cuisine_type" name="cuisine_type" required maxlength="50">
        </div>
        <div>
            <label for="phone_number">전화번호 (선택 사항):</label>
            <input type="text" id="phone_number" name="phone_number" maxlength="20">
        </div>
        <div>
            <label for="rating">평점 (1.0~5.0):</label>
            <input type="number" id="rating" name="rating" step="0.1" min="1.0" max="5.0" required>
        </div>
        <div>
            <label for="opening_hours">영업 시간 (선택 사항):</label>
            <input type="text" id="opening_hours" name="opening_hours" maxlength="100">
        </div>
        <div>
            <label for="description">설명:</label>
            <textarea id="description" name="description" rows="10" required></textarea>
        </div>
        <div>
            <label for="image">이미지 업로드 (선택 사항):</label>
            <input type="file" id="image" name="image" accept="image/*">
        </div>
        <div class="button-group">
            <input type="submit" value="맛집 추가">
            <a href="index.php" class="btn" style="background-color: #6c757d;">취소</a>
        </div>
    </form>
</section>

<?php
// footer.php 파일 포함
include_once "footer.php";
?>