<?php
session_start(); // 세션 시작

// 로그인 여부 확인
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인이 필요한 서비스입니다.');</script>";
    echo "<script>window.location.href='login.php';</script>"; // 로그인 페이지로 리다이렉트
    exit;
}

// 데이터베이스 연결
require_once 'db_connect.php'; // db_connect.php 파일 포함

// login_process.php에서 $_SESSION['userid']에 users.id (INT)가 저장되므로 이를 직접 사용
$user_db_id = $_SESSION['userid']; // 실제 users 테이블의 id (INT)
$username = ''; // 표시용 username 변수 초기화
$user_info = ['username' => '', 'nickname' => '', 'email' => '']; // 기본값 설정

// users 테이블에서 username, nickname, email 가져오기
$sql_user_info = "SELECT username, nickname, email FROM users WHERE id = ?";
$stmt_user_info = mysqli_prepare($conn, $sql_user_info);
// id는 INT이므로 "i"로 바인딩
mysqli_stmt_bind_param($stmt_user_info, "i", $user_db_id);
mysqli_stmt_execute($stmt_user_info);
$result_user_info = mysqli_stmt_get_result($stmt_user_info);

if ($result_user_info && mysqli_num_rows($result_user_info) > 0) {
    $user_info = mysqli_fetch_assoc($result_user_info);
    $username = $user_info['username']; // 표시용 username 변수 설정
} else {
    // 세션에 있는 user_db_id가 DB에 없는 경우 (비정상)
    session_unset();
    session_destroy();
    echo "<script>alert('사용자 정보를 찾을 수 없습니다. 다시 로그인해주세요.');</script>";
    echo "<script>window.location.href='login.php';</script>";
    exit;
}
mysqli_stmt_close($stmt_user_info);


// ----------------------------------------------------------------------
// 1. 내가 작성한 맛집 목록 조회 (mapjip 테이블)
$mapjips_per_page = 5; // 한 페이지당 맛집 개수

// 현재 맛집 페이지 번호 가져오기 (기본값 1)
$current_mapjip_page = isset($_GET['mapjip_page']) ? (int)$_GET['mapjip_page'] : 1;
if ($current_mapjip_page < 1) {
    $current_mapjip_page = 1;
}

// 전체 맛집 개수 조회
$sql_total_mapjips = "SELECT COUNT(*) AS total FROM mapjip WHERE user_id = ?";
$stmt_total_mapjips = mysqli_prepare($conn, $sql_total_mapjips);
mysqli_stmt_bind_param($stmt_total_mapjips, "i", $user_db_id);
mysqli_stmt_execute($stmt_total_mapjips);
$result_total_mapjips = mysqli_stmt_get_result($stmt_total_mapjips);
$total_mapjips = mysqli_fetch_assoc($result_total_mapjips)['total'];
mysqli_stmt_close($stmt_total_mapjips);

// 전체 맛집 페이지 수 계산
$total_mapjip_pages = ceil($total_mapjips / $mapjips_per_page);
if ($total_mapjip_pages == 0) { // 맛집이 없을 경우 최소 1페이지로 설정
    $total_mapjip_pages = 1;
}
// 현재 페이지가 전체 페이지 수를 초과하지 않도록 조정
if ($current_mapjip_page > $total_mapjip_pages) {
    $current_mapjip_page = $total_mapjip_pages;
}


// 맛집 목록 조회 (페이지네이션 적용)
$offset_mapjip = ($current_mapjip_page - 1) * $mapjips_per_page;
$my_mapjips = [];
$sql_my_mapjips = "SELECT id, name, address, created_at FROM mapjip WHERE user_id = ? ORDER BY created_at DESC LIMIT ?, ?";
$stmt_mapjips = mysqli_prepare($conn, $sql_my_mapjips);
// user_id는 INT, offset과 limit은 INT이므로 "iii"
mysqli_stmt_bind_param($stmt_mapjips, "iii", $user_db_id, $offset_mapjip, $mapjips_per_page);
mysqli_stmt_execute($stmt_mapjips);
$result_my_mapjips = mysqli_stmt_get_result($stmt_mapjips);

if ($result_my_mapjips) {
    while ($row = mysqli_fetch_assoc($result_my_mapjips)) {
        $my_mapjips[] = $row;
    }
}
mysqli_stmt_close($stmt_mapjips);

// ----------------------------------------------------------------------
// 2. 내가 작성한 게시물(리뷰) 목록 조회 (posts 테이블)
$posts_per_page = 5; // 한 페이지당 리뷰 개수

// 현재 리뷰 페이지 번호 가져오기 (기본값 1)
$current_post_page = isset($_GET['post_page']) ? (int)$_GET['post_page'] : 1;
if ($current_post_page < 1) {
    $current_post_page = 1;
}

// 전체 리뷰 개수 조회
$sql_total_posts = "SELECT COUNT(*) AS total FROM posts WHERE user_id = ?";
$stmt_total_posts = mysqli_prepare($conn, $sql_total_posts);
mysqli_stmt_bind_param($stmt_total_posts, "i", $user_db_id);
mysqli_stmt_execute($stmt_total_posts);
$result_total_posts = mysqli_stmt_get_result($stmt_total_posts);
$total_posts = mysqli_fetch_assoc($result_total_posts)['total'];
mysqli_stmt_close($stmt_total_posts);

// 전체 리뷰 페이지 수 계산
$total_post_pages = ceil($total_posts / $posts_per_page);
if ($total_post_pages == 0) { // 리뷰가 없을 경우 최소 1페이지로 설정
    $total_post_pages = 1;
}
// 현재 페이지가 전체 페이지 수를 초과하지 않도록 조정
if ($current_post_page > $total_post_pages) {
    $current_post_page = $total_post_pages;
}

// 리뷰 목록 조회 (페이지네이션 적용)
$offset_post = ($current_post_page - 1) * $posts_per_page;
$my_posts = [];
$sql_my_posts = "SELECT p.id, p.title, p.content, p.created_at, p.mapjip_id, m.name as mapjip_name
                 FROM posts p
                 JOIN mapjip m ON p.mapjip_id = m.id
                 WHERE p.user_id = ?
                 ORDER BY p.created_at DESC
                 LIMIT ?, ?"; // LIMIT와 OFFSET 추가
$stmt_posts = mysqli_prepare($conn, $sql_my_posts);
// user_id는 INT, offset과 limit은 INT이므로 "iii"
mysqli_stmt_bind_param($stmt_posts, "iii", $user_db_id, $offset_post, $posts_per_page);
mysqli_stmt_execute($stmt_posts);
$result_my_posts = mysqli_stmt_get_result($stmt_posts);

if ($result_my_posts) {
    while ($row = mysqli_fetch_assoc($result_my_posts)) {
        $my_posts[] = $row;
    }
}
mysqli_stmt_close($stmt_posts);

// DB 연결 종료
mysqli_close($conn);

// 헤더 파일 포함
require_once 'header.php';
?>

<main>
    <section class="mypage-section">
        <h2><?php echo htmlspecialchars($username); ?>님의 마이페이지</h2>

        <h3>회원 정보 수정</h3>
        <form action="update_user_info_process.php" method="POST">
            <input type="hidden" name="user_db_id" value="<?php echo htmlspecialchars($user_db_id); ?>"> <p>
                <label for="username_display">아이디:</label>
                <input type="text" id="username_display" value="<?php echo htmlspecialchars($username); ?>" disabled>
            </p>
            <p>
                <label for="nickname">닉네임:</label>
                <input type="text" id="nickname" name="nickname" value="<?php echo htmlspecialchars($user_info['nickname']); ?>" required>
            </p>
            <p>
                <label for="email">이메일:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_info['email']); ?>" required>
            </p>
            <p>
                <label for="password">비밀번호 변경:</label>
                <input type="password" id="password" name="password" minlength="6" placeholder="새 비밀번호 (변경 시 입력)">
                <small>비밀번호를 변경하지 않으려면 비워두세요.</small>
            </p>
            <p>
                <label for="password_confirm">비밀번호 확인:</label>
                <input type="password" id="password_confirm" name="password_confirm" minlength="6" placeholder="새 비밀번호 다시 입력">
            </p>
            <button type="submit" name="update_user_info">정보 수정</button>
        </form>

        <h3>내가 등록한 맛집 목록</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>맛집 이름</th>
                    <th>주소</th>
                    <th>등록일</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($my_mapjips) > 0): ?>
                    <?php foreach ($my_mapjips as $mapjip): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($mapjip['name']); ?></td>
                            <td><?php echo htmlspecialchars($mapjip['address']); ?></td>
                            <td><?php echo htmlspecialchars($mapjip['created_at']); ?></td>
                            <td>
                                <a href="view.php?id=<?php echo htmlspecialchars($mapjip['id']); ?>">상세</a> |
                                <a href="edit_form.php?id=<?php echo htmlspecialchars($mapjip['id']); ?>&type=mapjip">수정</a> |
                                <a href="delete_process.php?id=<?php echo htmlspecialchars($mapjip['id']); ?>&type=mapjip" onclick="return confirm('정말 이 맛집을 삭제하시겠습니까? 관련 리뷰도 모두 삭제됩니다.');">삭제</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">아직 등록한 맛집이 없습니다.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination">
            <?php if ($total_mapjip_pages > 1): ?>
                <?php if ($current_mapjip_page > 1): ?>
                    <a href="?mapjip_page=<?php echo $current_mapjip_page - 1; ?>&post_page=<?php echo $current_post_page; ?>">이전</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_mapjip_pages; $i++): ?>
                    <a href="?mapjip_page=<?php echo $i; ?>&post_page=<?php echo $current_post_page; ?>" class="<?php echo ($i == $current_mapjip_page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>

                <?php if ($current_mapjip_page < $total_mapjip_pages): ?>
                    <a href="?mapjip_page=<?php echo $current_mapjip_page + 1; ?>&post_page=<?php echo $current_post_page; ?>">다음</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>


        <h3>내가 작성한 리뷰 목록</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>리뷰 대상 맛집</th>
                    <th>제목</th>
                    <th>내용</th>
                    <th>작성일</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($my_posts) > 0): ?>
                    <?php foreach ($my_posts as $post): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($post['mapjip_name']); ?></td>
                            <td><?php echo htmlspecialchars($post['title']); ?></td>
                            <td><?php echo htmlspecialchars(mb_substr($post['content'], 0, 50, 'utf-8')) . (mb_strlen($post['content'], 'utf-8') > 50 ? '...' : ''); ?></td>
                            <td><?php echo htmlspecialchars($post['created_at']); ?></td>
                            <td>
                                <a href="view.php?id=<?php echo htmlspecialchars($post['mapjip_id']); ?>">상세</a> |
                                <a href="edit_review_form.php?id=<?php echo htmlspecialchars($post['id']); ?>">수정</a> |
                                <a href="delete_review_process.php?id=<?php echo htmlspecialchars($post['id']); ?>" onclick="return confirm('정말 이 리뷰를 삭제하시겠습니까?');">삭제</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5">아직 작성한 리뷰가 없습니다.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination">
            <?php if ($total_post_pages > 1): ?>
                <?php if ($current_post_page > 1): ?>
                    <a href="?mapjip_page=<?php echo $current_mapjip_page; ?>&post_page=<?php echo $current_post_page - 1; ?>">이전</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_post_pages; $i++): ?>
                    <a href="?mapjip_page=<?php echo $current_mapjip_page; ?>&post_page=<?php echo $i; ?>" class="<?php echo ($i == $current_post_page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>

                <?php if ($current_post_page < $total_post_pages): ?>
                    <a href="?mapjip_page=<?php echo $current_mapjip_page; ?>&post_page=<?php echo $current_post_page + 1; ?>">다음</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
            <br>
        <p>
            <button type="button" onclick="if(confirm('정말 회원 탈퇴를 하시겠습니까? 모든 정보가 삭제되며 되돌릴 수 없습니다.')) { location.href='delete_account_process.php'; }">회원 탈퇴</button>
        </p>
    </section>
</main>

<?php
// 푸터 파일 포함
require_once 'footer.php';
?>