<?php
session_start();
include_once "db_connect.php";

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 이용해주세요.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['userid'];
    $mapjip_id = $_POST['mapjip_id'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    // 2. 필수 입력 필드 검사 및 mapjip_id 유효성 추가
    if (empty($mapjip_id) || !is_numeric($mapjip_id) || (int)$mapjip_id <= 0 || empty($title) || empty($content)) {
        echo "<script>alert('모든 필수 항목을 올바르게 입력해주세요. 맛집을 선택했는지 확인해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // --- 3. 데이터베이스 삽입 ---
   
    $sql = "INSERT INTO posts (user_id, mapjip_id, title, content) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === FALSE) {
        die("리뷰 작성 SQL 준비 오류: " . $conn->error);
    }

    // 바인딩 파라미터도 mapjip_id 변수를 사용
    $stmt->bind_param("iiss", $user_id, $mapjip_id, $title, $content);

    if ($stmt->execute()) {
        echo "<script>alert('리뷰가 성공적으로 작성되었습니다.');</script>";
        echo "<script>window.location.href = 'view.php?id=" . htmlspecialchars($mapjip_id) . "';</script>";
    } else {
        echo "<script>alert('리뷰 작성에 실패했습니다: " . $stmt->error . "');</script>";
        echo "<script>window.history.back();</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
}

$conn->close();
?>