<?php
session_start(); // 세션 시작 (로그인 상태 유지를 위해 필수)
include_once "db_connect.php"; // 데이터베이스 연결 파일 포함

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // 1. 필수 입력 필드 검사
    if (empty($username) || empty($password)) {
        echo "<script>alert('아이디와 비밀번호를 모두 입력해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // 2. 데이터베이스에서 사용자 정보 가져오기
    $sql = "SELECT id, username, password, nickname FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === FALSE) {
        die("로그인 SQL 준비 오류: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // 3. 비밀번호 검증 (암호화된 비밀번호와 비교)
        // password_verify() 함수는 입력된 평문 비밀번호와 해시된 비밀번호를 비교합니다.
        if (password_verify($password, $user['password'])) {
            // 로그인 성공! 세션에 사용자 정보 저장
            $_SESSION['userid'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nickname'] = $user['nickname']; // 닉네임도 세션에 저장하여 활용 가능

            echo "<script>alert('" . htmlspecialchars($user['nickname']) . "님, 로그인 되었습니다.');</script>";
            echo "<script>window.location.href = 'index.php';</script>"; // 로그인 후 홈으로 이동
        } else {
            // 비밀번호 불일치
            echo "<script>alert('아이디 또는 비밀번호가 올바르지 않습니다.');</script>";
            echo "<script>window.history.back();</script>";
        }
    } else {
        // 사용자 아이디를 찾을 수 없음
        echo "<script>alert('아이디 또는 비밀번호가 올바르지 않습니다.');</script>";
        echo "<script>window.history.back();</script>";
    }

    $stmt->close();
} else {
    // POST 요청이 아닌 경우 (직접 접근 방지)
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
}

$conn->close(); // 데이터베이스 연결 닫기
?>