<?php
include_once "header.php";
include_once "db_connect.php";

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 이용해주세요.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

$matjips = []; // 맛집 목록을 저장할 배열

$sql = "SELECT id, name FROM mapjip ORDER BY name ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $matjips[] = $row;
    }
} else {
    echo "<script>alert('등록된 맛집이 없습니다. 먼저 맛집을 추가해주세요.');</script>";
    echo "<script>window.location.href = 'add_form.php';</script>";
    exit();
}

$conn->close();
?>
<section>
    <h2>리뷰 작성하기</h2>
    <form action="write_process.php" method="POST">
        <div>
            <label for="mapjip_id">맛집 선택:</label> <select id="mapjip_id" name="mapjip_id" required> <option value="" disabled selected>맛집을 선택해주세요</option>
                <?php foreach ($matjips as $matjip): ?>
                    <option value="<?= htmlspecialchars($matjip['id']) ?>">
                        <?= htmlspecialchars($matjip['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="title">리뷰 제목:</label>
            <input type="text" id="title" name="title" required maxlength="100">
        </div>
        <div>
            <label for="content">리뷰 내용:</label>
            <textarea id="content" name="content" rows="10" required></textarea>
        </div>
        <div class="button-group">
            <input type="submit" value="리뷰 작성">
            <a href="index.php" class="btn" style="background-color: #6c757d;">취소</a>
        </div>
    </form>
</section>
<?php
include_once "footer.php";
?>