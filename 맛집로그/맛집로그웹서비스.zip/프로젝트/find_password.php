<?php
// find_password.php
include_once "header.php"; // 세션 시작과 공통 헤더 포함
include_once "db_connect.php"; // 데이터베이스 연결 파일 포함

$message = "";
$message_type = ""; // 'alert' for error, 'success' for success
$show_password_form = false; // 새 비밀번호 입력 폼을 보여줄지 여부

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_input = $_POST['username'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $action = $_POST['action'] ?? ''; // 'verify' or 'reset'

    if ($action === 'verify') {
        // 1단계: 아이디 확인
        if (empty($username_input)) {
            $message = "아이디를 입력해주세요.";
            $message_type = "alert";
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->bind_param("s", $username_input);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // 아이디가 존재하면 세션에 저장하고 비밀번호 변경 폼을 보여줌
                $_SESSION['reset_username'] = $username_input;
                $show_password_form = true;
                $message = "아이디가 확인되었습니다. 새 비밀번호를 입력해주세요.";
                $message_type = "success";
            } else {
                $message = "존재하지 않는 아이디입니다.";
                $message_type = "alert";
            }
            $stmt->close();
        }
    } elseif ($action === 'reset') {
        // 2단계: 비밀번호 재설정
        $username_to_reset = $_SESSION['reset_username'] ?? '';

        if (empty($username_to_reset)) {
            $message = "잘못된 접근입니다. 다시 아이디를 입력해주세요.";
            $message_type = "alert";
            $show_password_form = false; // 다시 아이디 입력 폼으로
        } elseif (empty($new_password) || empty($confirm_password)) {
            $message = "새 비밀번호와 비밀번호 확인을 모두 입력해주세요.";
            $message_type = "alert";
            $show_password_form = true; // 비밀번호 폼 유지
        } elseif ($new_password !== $confirm_password) {
            $message = "새 비밀번호와 비밀번호 확인이 일치하지 않습니다.";
            $message_type = "alert";
            $show_password_form = true; // 비밀번호 폼 유지
        } elseif (strlen($new_password) < 6) { // 최소 비밀번호 길이 설정
            $message = "비밀번호는 최소 6자 이상이어야 합니다.";
            $message_type = "alert";
            $show_password_form = true; // 비밀번호 폼 유지
        } else {
            // 비밀번호 해쉬
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
            $stmt->bind_param("ss", $hashed_password, $username_to_reset);

            if ($stmt->execute()) {
                $message = "비밀번호가 성공적으로 변경되었습니다. 이제 새 비밀번호로 로그인할 수 있습니다.";
                $message_type = "success";
                unset($_SESSION['reset_username']); // 세션에서 아이디 정보 제거
                // 성공 후 로그인 페이지로 리다이렉트
                echo "<script>alert('비밀번호가 성공적으로 변경되었습니다. 로그인 페이지로 이동합니다.');</script>";
                echo "<script>window.location.href = 'login.php';</script>";
                exit();
            } else {
                $message = "비밀번호 변경에 실패했습니다. 잠시 후 다시 시도해주세요.";
                $message_type = "alert";
                $show_password_form = true; // 실패 시에도 비밀번호 폼 유지
            }
            $stmt->close();
        }
    }
}
$conn->close();
?>

<section>
    <h2>비밀번호 찾기 (변경)</h2>
    <?php if ($message): ?>
        <div class="<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if (!$show_password_form): // 아이디 입력 폼 ?>
        <form action="find_password.php" method="POST">
            <input type="hidden" name="action" value="verify">
            <div>
                <label for="username">아이디:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="button-group">
                <input type="submit" value="아이디 확인">
                <a href="login.php" class="btn" style="background-color: #6c757d;">로그인으로 돌아가기</a>
            </div>
        </form>
    <?php else: // 새 비밀번호 입력 폼 ?>
        <form action="find_password.php" method="POST">
            <input type="hidden" name="action" value="reset">
            <input type="hidden" name="username" value="<?php echo htmlspecialchars($_SESSION['reset_username'] ?? ''); ?>">
            <div>
                <label for="new_password">새 비밀번호:</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div>
                <label for="confirm_password">새 비밀번호 확인:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <div class="button-group">
                <input type="submit" value="비밀번호 변경">
                <a href="login.php" class="btn" style="background-color: #6c757d;">로그인으로 돌아가기</a>
            </div>
        </form>
    <?php endif; ?>
</section>

<?php
include_once "footer.php";
?>