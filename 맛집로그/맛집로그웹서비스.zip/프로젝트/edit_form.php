<?php
include_once "header.php";
include_once "db_connect.php";

// 로그인하지 않은 사용자는 접근 불가능
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 맛집 정보를 수정할 수 있습니다.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

$matjip = null;
$matjip_id = $_GET['id'] ?? null;

if ($matjip_id && is_numeric($matjip_id)) {
    $sql = "SELECT * FROM mapjip WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === FALSE) { die("SQL 준비 오류: " . $conn->error); }
    $stmt->bind_param("i", $matjip_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $matjip = $result->fetch_assoc();
    
        // 맛집 등록자와 현재 로그인된 사용자가 일치하는지 확인
        if ($matjip['user_id'] != $_SESSION['userid']) {
            echo "<script>alert('본인이 등록한 맛집만 수정할 수 있습니다.');</script>";
            echo "<script>window.location.href = 'view.php?id=" . htmlspecialchars($matjip_id) . "';</script>";
            exit();
        }
       
    } else {
        echo "<script>alert('해당 맛집 정보를 찾을 수 없습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $stmt->close();
} else {
    echo "<script>alert('잘못된 접근입니다. 맛집 ID가 필요합니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
    exit();
}
?>

<section>
    <h2>맛집 정보 수정</h2>
    <?php if ($matjip): ?>
        <form action="edit_process.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= htmlspecialchars($matjip['id']) ?>">
            <div>
                <label for="name">맛집 이름:</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($matjip['name']) ?>" required maxlength="100">
            </div>
            <div>
                <label for="address">주소:</label>
                <input type="text" id="address" name="address" value="<?= htmlspecialchars($matjip['address']) ?>" required maxlength="255">
            </div>
            <div>
                <label for="cuisine_type">음식 종류:</label>
                <input type="text" id="cuisine_type" name="cuisine_type" value="<?= htmlspecialchars($matjip['cuisine_type']) ?>" required maxlength="50">
            </div>
            <div>
                <label for="phone_number">전화번호 (선택 사항):</label>
                <input type="text" id="phone_number" name="phone_number" value="<?= htmlspecialchars($matjip['phone_number']) ?>" maxlength="20">
            </div>
            <div>
                <label for="rating">평점 (1.0~5.0):</label>
                <input type="number" id="rating" name="rating" step="0.1" min="1.0" max="5.0" value="<?= htmlspecialchars($matjip['rating']) ?>" required>
            </div>
            <div>
                <label for="opening_hours">영업 시간 (선택 사항):</label>
                <input type="text" id="opening_hours" name="opening_hours" value="<?= htmlspecialchars($matjip['opening_hours']) ?>" maxlength="100">
            </div>
            <div>
                <label for="description">설명:</label>
                <textarea id="description" name="description" rows="10" required><?= htmlspecialchars($matjip['description']) ?></textarea>
            </div>
            <div>
                <label for="current_image">현재 이미지:</label>
                <?php if ($matjip['image_path'] && file_exists($matjip['image_path'])): ?>
                    <img src="<?= htmlspecialchars($matjip['image_path']) ?>" alt="현재 이미지" style="max-width: 200px; height: auto; display: block; margin-bottom: 10px;">
                    <input type="hidden" name="existing_image_path" value="<?= htmlspecialchars($matjip['image_path']) ?>">
                <?php else: ?>
                    <span>이미지 없음</span>
                <?php endif; ?>
                <label for="image" style="margin-top: 10px; display: block;">새 이미지 업로드 (교체):</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>
            <div class="button-group">
                <input type="submit" value="수정 완료">
                <a href="view.php?id=<?= htmlspecialchars($matjip['id']) ?>" class="btn" style="background-color: #6c757d;">취소</a>
            </div>
        </form>
    <?php endif; ?>
</section>

<?php
$conn->close();
include_once "footer.php";
?>