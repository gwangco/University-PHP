<?php

include_once "header.php";

// 이미 로그인되어 있다면 index.php로 리다이렉트
if (isset($_SESSION['userid'])) {
    echo "<script>alert('이미 로그인되어 있습니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
    exit();
}
?>
<section>
    <h2>로그인</h2>
    <form action="login_process.php" method="POST">
        <div>
            <label for="username">아이디:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">비밀번호:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="button-group">
            <input type="submit" value="로그인">
            <a href="join_form.php" class="btn" style="background-color: #007bff;">회원가입</a>
            <a href="index.php" class="btn" style="background-color: #6c757d;">취소</a>
        </div>

        <div class="find-links" style="margin-top: 15px; text-align: center;">
            <a href="#" onclick="openFindIdPopup(); return false;"
               style="margin-right: 10px; color: #007bff; text-decoration: none;">아이디 찾기</a>
            <a href="find_password.php" style="color: #007bff; text-decoration: none;">비밀번호 찾기</a>
        </div>
    </form>
</section>

<script>
let findIdWindow = null; // 팝업 창 객체를 저장할 변수

function openFindIdPopup() {
    // 팝업 창이 이미 열려 있고 닫히지 않았다면 다시 열지 않음
    if (findIdWindow && !findIdWindow.closed) {
        findIdWindow.focus(); // 이미 열려있는 창이 있다면 해당 창으로 포커스
        return; // 함수 종료
    }

    // 팝업 창 열기

    findIdWindow = window.open('find_id.php', 'findIdPopup', 'width=400,height=600,scrollbars=yes,resizable=no');

    // 팝업 창이 정상적으로 열렸는지 확인 (팝업 차단 등으로 열리지 않을 수 있음)
    if (findIdWindow) {
        findIdWindow.focus();
    } else {
        alert("팝업이 차단되었습니다. 팝업 차단을 해제해주세요.");
    }
}
</script>

<?php
include_once "footer.php";
?>