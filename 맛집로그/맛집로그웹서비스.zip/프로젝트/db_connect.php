<?php
// 데이터베이스 연결 설정
$servername = ""; // MySQL 서버 주소 (대부분의 로컬 개발 환경에서는 localhost)
$username = ""; // MySQL 사용자 이름 (예: root)
$password = ""; // MySQL 비밀번호
$dbname = ""; // 생성한 데이터베이스 이름

// 데이터베이스 연결 시도 (MySQLi 사용)
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 오류 확인
if ($conn->connect_error) {
    // 연결 실패 시 오류 메시지 출력 후 스크립트 종료
    die("데이터베이스 연결 실패: " . $conn->connect_error);
}
// 연결 성공 시 (테스트용, 나중에 주석 처리하거나 삭제)
// echo "데이터베이스 연결 성공!";

// 문자셋 설정 (한글 깨짐 방지)
$conn->set_charset("utf8mb4");
?>