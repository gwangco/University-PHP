<?php

include_once "header.php";
include_once "db_connect.php";

$matjip = null;
$reviews = [];

// 세션 시작 (로그인 정보 사용을 위해 필요)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $matjip_id = (int)$_GET['id'];

    // 맛집 정보 가져오기: 'mapjip' 테이블 사용
    $sql_matjip = "SELECT * FROM mapjip WHERE id = ?";
    $stmt_matjip = $conn->prepare($sql_matjip);

    if ($stmt_matjip === FALSE) {
        die("맛집 정보 SQL 준비 오류: " . $conn->error);
    }
    $stmt_matjip->bind_param("i", $matjip_id);
    $stmt_matjip->execute();
    $result_matjip = $stmt_matjip->get_result();

    if ($result_matjip->num_rows > 0) {
        $matjip = $result_matjip->fetch_assoc();
    } else {
        echo "<script>alert('해당 맛집 정보를 찾을 수 없습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $stmt_matjip->close();

    // --- 리뷰 페이지네이션 설정 시작 ---
    $reviews_per_page = 5; // 페이지당 출력할 리뷰 수
    $current_review_page = isset($_GET['rpage']) && is_numeric($_GET['rpage']) ? (int)$_GET['rpage'] : 1;
    $offset_reviews = ($current_review_page - 1) * $reviews_per_page;

    // 전체 리뷰 수 계산
    $count_reviews_sql = "SELECT COUNT(*) AS total_reviews FROM posts WHERE mapjip_id = ?";
    $stmt_count_reviews = $conn->prepare($count_reviews_sql);
    $stmt_count_reviews->bind_param("i", $matjip_id);
    $stmt_count_reviews->execute();
    $total_reviews = $stmt_count_reviews->get_result()->fetch_assoc()['total_reviews'];
    $stmt_count_reviews->close();

    // 총 리뷰 페이지 수 계산
    $total_review_pages = ceil($total_reviews / $reviews_per_page);
    // --- 리뷰 페이지네이션 설정 끝 ---

    // --- **여기서 각 리뷰(게시물)의 조회수(views)를 일괄 증가시킵니다.** ---
    // 이 맛집에 속한 모든 리뷰들의 views를 1씩 증가시킵니다.
    // 주의: 이 방식은 페이지 방문 시 해당 맛집의 모든 리뷰의 조회수를 증가시킵니다.
    // 한 명의 사용자가 여러 번 새로고침해도 한 번만 증가하게 하려면 세션이나 쿠키를 활용해야 합니다.
    $update_posts_views_sql = "UPDATE posts SET views = views + 1 WHERE mapjip_id = ?";
    $stmt_update_posts_views = $conn->prepare($update_posts_views_sql);
    if ($stmt_update_posts_views === FALSE) {
        error_log("리뷰 조회수 일괄 업데이트 SQL 준비 오류: " . $conn->error);
    } else {
        $stmt_update_posts_views->bind_param("i", $matjip_id);
        $stmt_update_posts_views->execute();
        $stmt_update_posts_views->close();
    }
   


    // 리뷰 정보 가져오기 (posts 테이블의 mapjip_id 컬럼 사용)
    // 페이지네이션 LIMIT, OFFSET 적용
    
    $sql_reviews = "SELECT p.*, u.nickname FROM posts p JOIN users u ON p.user_id = u.id WHERE p.mapjip_id = ? ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
    $stmt_reviews = $conn->prepare($sql_reviews);
    if ($stmt_reviews === FALSE) {
        die("리뷰 정보 SQL 준비 오류: " . $conn->error);
    }
    // 바인딩 파라미터에 LIMIT과 OFFSET 값 추가
    $stmt_reviews->bind_param("iii", $matjip_id, $reviews_per_page, $offset_reviews);
    $stmt_reviews->execute();
    $result_reviews = $stmt_reviews->get_result();
    if ($result_reviews->num_rows > 0) {
        while ($row = $result_reviews->fetch_assoc()) {
            $reviews[] = $row;
        }
    }
    $stmt_reviews->close();

} else {
    echo "<script>alert('잘못된 접근입니다. 맛집 ID가 필요합니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
    exit();
}
?>

<section>
    <?php if ($matjip): ?>
        <h2><?= htmlspecialchars($matjip['name']) ?></h2>
        <div class="matjip-detail">
            <?php
            $image_path = $matjip['image_path'];
            if ($image_path && file_exists($image_path)):
            ?>
                <img src="<?= htmlspecialchars($image_path) ?>" alt="<?= htmlspecialchars($matjip['name']) ?>">
            <?php else: ?>
                <img src="https://via.placeholder.com/400x300?text=No+Image" alt="이미지 없음">
            <?php endif; ?>

            <p><strong>주소:</strong> <?= htmlspecialchars($matjip['address']) ?></p>
            <p><strong>음식 종류:</strong> <?= htmlspecialchars($matjip['cuisine_type']) ?></p>
            <?php if (!empty($matjip['phone_number'])): ?>
                <p><strong>전화번호:</strong> <?= htmlspecialchars($matjip['phone_number']) ?></p>
            <?php endif; ?>
            <p><strong>평점:</strong> <?= htmlspecialchars($matjip['rating']) ?> / 5.0</p>
            <?php if (!empty($matjip['opening_hours'])): ?>
                <p><strong>영업 시간:</strong> <?= htmlspecialchars($matjip['opening_hours']) ?></p>
            <?php endif; ?>
            <p><strong>설명:</strong></p>
            <div style="white-space: pre-wrap; border: 1px solid #eee; padding: 10px; background-color: #f9f9f9; border-radius: 5px;">
                <?= htmlspecialchars($matjip['description']) ?>
            </div>
            <p><strong>등록일:</strong> <?= htmlspecialchars($matjip['created_at']) ?></p>

            <div class="button-group" style="margin-top: 30px;">
                <?php
                if (isset($_SESSION['userid']) && isset($matjip['user_id']) && $_SESSION['userid'] == $matjip['user_id']):
                ?>
                    <a href="edit_form.php?id=<?= $matjip['id'] ?>" class="btn btn-success">수정</a>
                    <a href="delete_process.php?id=<?= $matjip['id'] ?>&type=mapjip" class="btn btn-danger" onclick="return confirm('정말로 이 맛집과 관련된 모든 리뷰를 포함하여 삭제하시겠습니까?');">삭제</a>

                <?php endif; ?>
                <a href="index.php" class="btn btn-secondary">목록으로</a>
            </div>
        </div>

        <h3 style="margin-top: 40px;">이 맛집에 대한 리뷰</h3>
        <?php if (!empty($reviews)): ?>
            <div class="reviews-list">
                <?php foreach ($reviews as $review): ?>
                    <div class="review-item">
                        <br>
                        <h4>제목 : <?= htmlspecialchars($review['title']) ?></h4>
                        <p class="author-info">
                            작성자: <strong><?= htmlspecialchars($review['nickname']) ?></strong>
                            (<?= htmlspecialchars($review['created_at']) ?>)
                            <span> | 조회수: <?= htmlspecialchars($review['views']) ?></span>
                        </p>
                        <p style="white-space: pre-wrap;"><?= htmlspecialchars($review['content']) ?></p>
                        <?php
                        if (isset($_SESSION['userid']) && isset($review['user_id']) && $_SESSION['userid'] == $review['user_id']):
                        ?>
                            <div class="review-actions">
                                <a href="edit_review_form.php?id=<?= $review['id'] ?>" class="btn btn-sm btn-success">수정</a>
                                <a href="delete_review_process.php?id=<?= $review['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('정말로 이 리뷰를 삭제하시겠습니까?');">삭제</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div style="text-align: center; margin-top: 20px;">
                <?php if ($current_review_page > 1): ?>
                    <a href="?id=<?= $matjip['id'] ?>&rpage=<?= $current_review_page - 1 ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px;">이전</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_review_pages; $i++): ?>
                    <a href="?id=<?= $matjip['id'] ?>&rpage=<?= $i ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px; <?= ($i == $current_review_page) ? 'background-color: #007bff; color: white;' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($current_review_page < $total_review_pages): ?>
                    <a href="?id=<?= $matjip['id'] ?>&rpage=<?= $current_review_page + 1 ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px;">다음</a>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <p>아직 이 맛집에 대한 리뷰가 없습니다.</p>
        <?php endif; ?>
        <div style="margin-top: 20px;">
            <a href="write_form.php?mapjip_id=<?= $matjip['id'] ?>" class="btn btn-primary">새 리뷰 작성하기</a>
        </div>

    <?php endif; ?>
</section>

<?php
$conn->close();
include_once "footer.php";
?>