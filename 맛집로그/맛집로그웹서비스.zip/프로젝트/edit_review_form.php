<?php
include_once "header.php";
include_once "db_connect.php";

// 1. 로그인 여부 확인
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 이용해주세요.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

$review_id = $_GET['id'] ?? null; // GET으로 넘어온 리뷰 ID
$review = null;
$matjips = []; // 맛집 목록을 저장할 배열

if ($review_id && is_numeric($review_id)) {
    // 2. 리뷰 정보 가져오기 (작성자 확인 포함)
    $sql_review = "SELECT * FROM posts WHERE id = ?";
    $stmt_review = $conn->prepare($sql_review);
    if ($stmt_review === FALSE) {
        die("리뷰 조회 SQL 준비 오류: " . $conn->error);
    }
    $stmt_review->bind_param("i", $review_id);
    $stmt_review->execute();
    $result_review = $stmt_review->get_result();

    if ($result_review->num_rows > 0) {
        $review = $result_review->fetch_assoc();
        // 3. 본인 리뷰인지 확인
        if ($review['user_id'] != $_SESSION['userid']) {
            echo "<script>alert('본인이 작성한 리뷰만 수정할 수 있습니다.');</script>";
            echo "<script>window.location.href = 'index.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('해당 리뷰 정보를 찾을 수 없습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $stmt_review->close();

    // 4. 맛집 목록 가져오기 (드롭다운 메뉴용)
    $sql_matjips = "SELECT id, name FROM mapjip ORDER BY name ASC";
    $result_matjips = $conn->query($sql_matjips);
    if ($result_matjips->num_rows > 0) {
        while($row = $result_matjips->fetch_assoc()) {
            $matjips[] = $row;
        }
    } else {
        echo "<script>alert('등록된 맛집이 없습니다. 관리자에게 문의해주세요.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }

} else {
    echo "<script>alert('잘못된 접근입니다. 리뷰 ID가 필요합니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
    exit();
}

$conn->close();
?>
<section>
    <h2>리뷰 수정하기</h2>
    <?php if ($review): // 리뷰 정보가 있을 경우에만 폼 출력 ?>
        <form action="edit_review_process.php" method="POST">
            <input type="hidden" name="review_id" value="<?= htmlspecialchars($review['id']) ?>">

            <div>
                <label for="mapjip_id">맛집 선택:</label>
                <select id="mapjip_id" name="mapjip_id" required>
                    <option value="" disabled>맛집을 선택해주세요</option>
                    <?php foreach ($matjips as $matjip): ?>
                        <option value="<?= htmlspecialchars($matjip['id']) ?>"
                            <?= ($matjip['id'] == $review['mapjip_id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($matjip['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="title">리뷰 제목:</label>
                <input type="text" id="title" name="title" value="<?= htmlspecialchars($review['title']) ?>" required maxlength="100">
            </div>
            <div>
                <label for="content">리뷰 내용:</label>
                <textarea id="content" name="content" rows="10" required><?= htmlspecialchars($review['content']) ?></textarea>
            </div>
            <div class="button-group">
                <input type="submit" value="리뷰 수정">
                <a href="view.php?id=<?= htmlspecialchars($review['mapjip_id']) ?>" class="btn" style="background-color: #6c757d;">취소</a>
            </div>
        </form>
    <?php endif; ?>
</section>
<?php
include_once "footer.php";
?>