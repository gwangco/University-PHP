CREATE TABLE posts (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '게시물 고유 번호',
    user_id INT(11) NOT NULL COMMENT '작성자 ID (users 테이블 참조)',
    mapjip_id INT(11) NOT NULL COMMENT '맛집 ID (mapjip 테이블 참조)', 
    title VARCHAR(255) NOT NULL COMMENT '게시물 제목 (리뷰 제목)',
    content TEXT NOT NULL COMMENT '게시물 내용 (리뷰 내용)',
    views INT(11) DEFAULT 0 COMMENT '조회수',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '작성 일시',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '마지막 수정 일시',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mapjip_id) REFERENCES mapjip(id) ON DELETE CASCADE 
);