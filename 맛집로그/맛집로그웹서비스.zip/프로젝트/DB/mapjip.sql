CREATE TABLE mapjip (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '맛집 고유 번호',
    name VARCHAR(100) NOT NULL COMMENT '맛집 이름',
    address VARCHAR(255) NOT NULL COMMENT '주소',
    cuisine_type VARCHAR(50) COMMENT '음식 종류 (한식, 중식, 일식 등)',
    phone_number VARCHAR(20) COMMENT '전화번호',
    rating DECIMAL(2,1) COMMENT '평점 (0.0 ~ 5.0)',
    opening_hours VARCHAR(255) COMMENT '영업 시간',
    description TEXT COMMENT '맛집 설명',
    image_path VARCHAR(255) NULL COMMENT '대표 이미지 파일 경로',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '등록 일시',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '마지막 수정 일시'
);