<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인이 필요한 서비스입니다.');</script>";
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_user_info'])) {
    // $_SESSION['userid']에 users 테이블의 id(INT)가 저장되므로 이를 직접 사용
    $user_db_id = $_SESSION['userid']; 
    // mypage.php에서 hidden input으로 넘겨받은 user_db_id와 세션의 user_db_id가 일치하는지 확인 (선택 사항)
    // if (!isset($_POST['user_db_id']) || $_POST['user_db_id'] != $user_db_id) {
    //     echo "<script>alert('잘못된 사용자 정보 접근입니다. 보안 경고.');</script>";
    //     echo "<script>window.location.href='mypage.php';</script>";
    //     exit;
    // }

    $nickname = $_POST['nickname'];
    $email = $_POST['email'];
    $password = $_POST['password']; // 새 비밀번호
    $password_confirm = $_POST['password_confirm']; // 새 비밀번호 확인

    // 유효성 검사
    if (empty($nickname) || empty($email)) {
        echo "<script>alert('닉네임과 이메일은 필수 입력 사항입니다.');</script>";
        echo "<script>history.back();</script>";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('유효하지 않은 이메일 형식입니다.');</script>";
        echo "<script>history.back();</script>";
        exit;
    }

    $update_fields = [];
    $bind_types = "";
    $bind_params = [];

    // 닉네임 업데이트
    $update_fields[] = "nickname = ?";
    $bind_types .= "s";
    $bind_params[] = $nickname;

    // 이메일 업데이트
    $update_fields[] = "email = ?";
    $bind_types .= "s";
    $bind_params[] = $email;

    // 비밀번호 변경이 요청된 경우
    if (!empty($password)) {
        if ($password !== $password_confirm) {
            echo "<script>alert('새 비밀번호와 비밀번호 확인이 일치하지 않습니다.');</script>";
            echo "<script>history.back();</script>";
            exit;
        }
        // 비밀번호는 해시하여 저장
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update_fields[] = "password = ?";
        $bind_types .= "s";
        $bind_params[] = $hashed_password;
    }

    if (empty($update_fields)) {
        echo "<script>alert('변경할 정보가 없습니다.');</script>";
        echo "<script>window.location.href='mypage.php';</script>";
        exit;
    }

    $sql_update = "UPDATE users SET " . implode(", ", $update_fields) . " WHERE id = ?";
    $bind_types .= "i"; // 마지막 파라미터는 $user_db_id (INT)
    $bind_params[] = $user_db_id;

    $stmt = mysqli_prepare($conn, $sql_update);
    // 동적으로 바인딩할 파라미터 배열 생성
    $bind_refs = [];
    foreach ($bind_params as $key => $value) {
        $bind_refs[$key] = &$bind_params[$key];
    }
    // mysqli_stmt_bind_param()은 레퍼런스를 요구하므로 call_user_func_array 사용
    call_user_func_array('mysqli_stmt_bind_param', array_merge([$stmt, $bind_types], $bind_refs));

    if (mysqli_stmt_execute($stmt)) {
        // 닉네임이 변경되었다면 세션 닉네임도 업데이트
        if (in_array("nickname = ?", $update_fields)) {
            $_SESSION['nickname'] = $nickname;
        }
        echo "<script>alert('회원 정보가 성공적으로 수정되었습니다.');</script>";
        echo "<script>window.location.href='mypage.php';</script>";
    } else {
        echo "<script>alert('회원 정보 수정에 실패했습니다: " . mysqli_error($conn) . "');</script>";
        echo "<script>history.back();</script>";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

} else {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href='mypage.php';</script>";
}
?>