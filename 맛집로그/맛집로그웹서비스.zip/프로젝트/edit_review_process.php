<?php
session_start();
include_once "db_connect.php";

// 1. 로그인 여부 확인
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 이용해주세요.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 폼 데이터 가져오기
    $review_id = $_POST['review_id'] ?? '';
    $user_id = $_SESSION['userid']; // 세션에서 현재 로그인된 사용자 ID
    $mapjip_id = $_POST['mapjip_id'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    // 2. 필수 입력 필드 및 ID 유효성 검사
    if (empty($review_id) || !is_numeric($review_id) || empty($mapjip_id) || !is_numeric($mapjip_id) || (int)$mapjip_id <= 0 || empty($title) || empty($content)) {
        echo "<script>alert('모든 필수 항목을 올바르게 입력해주세요. 리뷰 ID와 맛집 선택을 확인해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // 3. 리뷰의 실제 작성자 확인 (보안 강화)
    $sql_check_owner = "SELECT user_id FROM posts WHERE id = ?";
    $stmt_check_owner = $conn->prepare($sql_check_owner);
    if ($stmt_check_owner === FALSE) {
        die("작성자 확인 SQL 준비 오류: " . $conn->error);
    }
    $stmt_check_owner->bind_param("i", $review_id);
    $stmt_check_owner->execute();
    $result_check_owner = $stmt_check_owner->get_result();

    if ($result_check_owner->num_rows == 0) {
        echo "<script>alert('해당 리뷰를 찾을 수 없습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $row_owner = $result_check_owner->fetch_assoc();
    if ($row_owner['user_id'] != $user_id) {
        echo "<script>alert('본인 리뷰만 수정할 수 있습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $stmt_check_owner->close();

    // 4. 데이터베이스 업데이트 (수정)
    // updated_at 필드는 CURRENT_TIMESTAMP로 자동 업데이트되도록 DB에 설정되어 있어야 합니다.
    $sql = "UPDATE posts SET mapjip_id = ?, title = ?, content = ? WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === FALSE) {
        die("리뷰 수정 SQL 준비 오류: " . $conn->error);
    }

    // 'isssi'는 mapjip_id(integer), title(string), content(string), id(integer), user_id(integer)
    $stmt->bind_param("issii", $mapjip_id, $title, $content, $review_id, $user_id);

    if ($stmt->execute()) {
        echo "<script>alert('리뷰가 성공적으로 수정되었습니다.');</script>";
        echo "<script>window.location.href = 'view.php?id=" . htmlspecialchars($mapjip_id) . "';</script>"; // 수정 후 해당 맛집 상세 페이지로 이동
    } else {
        echo "<script>alert('리뷰 수정에 실패했습니다: " . $stmt->error . "');</script>";
        echo "<script>window.history.back();</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
}

$conn->close();
?>