<?php

include_once "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 폼 데이터 가져오기
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $email = trim($_POST['email'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');

    // --- 1. 기본 유효성 검사 ---
    if (empty($username) || empty($password) || empty($password_confirm) || empty($email) || empty($nickname)) {
        echo "<script>alert('모든 필수 항목을 입력해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // --- 2. 비밀번호 일치 여부 확인 ---
    if ($password !== $password_confirm) {
        echo "<script>alert('비밀번호와 비밀번호 확인이 일치하지 않습니다.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // --- 3. 비밀번호 길이 검사 ---
    if (strlen($password) < 6) {
        echo "<script>alert('비밀번호는 최소 6자 이상이어야 합니다.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // --- 4. 아이디 중복 확인 (서버 측) ---
    $sql_check_username = "SELECT COUNT(*) FROM users WHERE username = ?";
    $stmt_check_username = $conn->prepare($sql_check_username);
    if ($stmt_check_username === FALSE) {
        die("아이디 중복 확인 SQL 준비 오류: " . $conn->error);
    }
    $stmt_check_username->bind_param("s", $username);
    $stmt_check_username->execute();
    $stmt_check_username->bind_result($username_count);
    $stmt_check_username->fetch();
    $stmt_check_username->close();

    if ($username_count > 0) {
        echo "<script>alert('이미 존재하는 아이디입니다. 다른 아이디를 사용해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    // --- 5. 이메일 중복 확인 (서버 측) ---
    $sql_check_email = "SELECT COUNT(*) FROM users WHERE email = ?";
    $stmt_check_email = $conn->prepare($sql_check_email);
    if ($stmt_check_email === FALSE) {
        die("이메일 중복 확인 SQL 준비 오류: " . $conn->error);
    }
    $stmt_check_email->bind_param("s", $email);
    $stmt_check_email->execute();
    $stmt_check_email->bind_result($email_count);
    $stmt_check_email->fetch();
    $stmt_check_email->close();

    if ($email_count > 0) {
        echo "<script>alert('이미 사용 중인 이메일입니다. 다른 이메일을 사용해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }
      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('유효하지 않은 이메일 형식입니다.');</script>";
        echo "<script>history.back();</script>";
        exit;
    }

    // --- 6. 비밀번호 암호화 (매우 중요!) ---
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // --- 7. 데이터베이스 삽입 ---
    $sql = "INSERT INTO users (username, password, email, nickname) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === FALSE) {
        die("회원가입 SQL 준비 오류: " . $conn->error);
    }

    $stmt->bind_param("ssss", $username, $hashed_password, $email, $nickname);

    if ($stmt->execute()) {
        echo "<script>alert('회원가입이 성공적으로 완료되었습니다. 로그인 해주세요.');</script>";
        // 로그인 페이지로 이동 (login.php는 루트에 생성될 것)
        echo "<script>window.location.href = 'login.php';</script>";
    } else {
        echo "<script>alert('회원가입에 실패했습니다: " . $stmt->error . "');</script>";
        echo "<script>window.history.back();</script>";
    }

    $stmt->close();
} else {
    // POST 요청이 아닌 경우 (직접 접근 방지)
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
}

$conn->close();
?>