<?php
session_start();
include_once "db_connect.php";

// 로그인하지 않은 사용자는 접근 불가능
if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 맛집 정보를 수정할 수 있습니다.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? '';
    $user_id = $_SESSION['userid']; // 현재 로그인된 사용자 ID

    // 필수 필드 유효성 검사
    if (empty($id) || !is_numeric($id)) {
        echo "<script>alert('잘못된 맛집 ID입니다.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

  
    // 맛집 소유자 확인
    $sql_check_owner = "SELECT user_id, image_path FROM mapjip WHERE id = ?";
    $stmt_check_owner = $conn->prepare($sql_check_owner);
    if ($stmt_check_owner === FALSE) {
        die("맛집 소유자 확인 SQL 준비 오류: " . $conn->error);
    }
    $stmt_check_owner->bind_param("i", $id);
    $stmt_check_owner->execute();
    $result_check_owner = $stmt_check_owner->get_result();

    if ($result_check_owner->num_rows == 0) {
        echo "<script>alert('해당 맛집 정보를 찾을 수 없습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    }
    $row_owner = $result_check_owner->fetch_assoc();
    $existing_image_path = $row_owner['image_path'] ?? null; // 기존 이미지 경로 가져옴 (아래 업로드 로직에서 사용)

    if ($row_owner['user_id'] != $user_id) {
        echo "<script>alert('본인이 등록한 맛집만 수정할 수 있습니다.');</script>";
        echo "<script>window.location.href = 'view.php?id=" . htmlspecialchars($id) . "';</script>";
        exit();
    }
    $stmt_check_owner->close();
    

    $name = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $cuisine_type = trim($_POST['cuisine_type'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    $rating = $_POST['rating'] ?? '';
    $opening_hours = trim($_POST['opening_hours'] ?? '');
    $description = trim($_POST['description'] ?? '');
    // $existing_image_path = $_POST['existing_image_path'] ?? ''; // 기존 이미지 경로는 위에서 DB에서 직접 가져오도록 변경됨

    // 나머지 유효성 검사는 기존과 동일
    if (empty($name) || empty($address) || empty($cuisine_type) || empty($rating) || !is_numeric($rating)) {
        echo "<script>alert('모든 필수 항목을 입력해주세요.');</script>";
        echo "<script>window.history.back();</script>";
        exit();
    }

    $image_path = $existing_image_path; // 기존 이미지 경로 유지

    // 이미지 파일 업로드 처리 (기존과 동일, $existing_image_path 사용)
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_file = $upload_dir . $file_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check === false) { echo "<script>alert('업로드된 파일이 이미지가 아닙니다.');</script>"; echo "<script>window.history.back();</script>"; exit(); }
        if ($_FILES['image']['size'] > 5000000) { echo "<script>alert('파일 크기가 너무 큽니다. (5MB 이하)');</script>"; echo "<script>window.history.back();</script>"; exit(); }
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") { echo "<script>alert('JPG, JPEG, PNG, GIF 파일만 허용됩니다.');</script>"; echo "<script>window.history.back();</script>"; exit(); }

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            if ($existing_image_path && file_exists($existing_image_path)) {
                unlink($existing_image_path);
            }
            $image_path = $target_file;
        } else {
            echo "<script>alert('파일 업로드에 실패했습니다.');</script>";
            echo "<script>window.history.back();</script>";
            exit();
        }
    }

    // 데이터베이스 업데이트 (user_id 조건 추가)
   // 데이터베이스 업데이트 (user_id 조건 추가)
$sql = "UPDATE mapjip SET name = ?, address = ?, cuisine_type = ?, phone_number = ?, rating = ?, opening_hours = ?, description = ?, image_path = ? WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === FALSE) {
    die("SQL 준비 오류: " . $conn->error);
}

// 올바른 개수의 변수 바인딩 (10개)
$stmt->bind_param("ssssdsssii", $name, $address, $cuisine_type, $phone_number, $rating, $opening_hours, $description, $image_path, $id, $user_id);



    if ($stmt->execute()) {
        echo "<script>alert('맛집 정보가 성공적으로 수정되었습니다.');</script>";
        echo "<script>window.location.href = 'view.php?id=" . htmlspecialchars($id) . "';</script>";
    } else {
        echo "<script>alert('맛집 정보 수정에 실패했습니다: " . $stmt->error . "');</script>";
        echo "<script>window.history.back();</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'index.php';</script>";
}

$conn->close();
?>