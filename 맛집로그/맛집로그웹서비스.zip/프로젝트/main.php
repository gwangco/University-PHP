<?php
include "db_connect.php"; // 데이터베이스 연결 파일 포함

// 세션 시작 (로그인 정보 사용을 위해 필요)

// 페이지네이션 설정
$records_per_page = 5; // 페이지당 출력할 맛집 수

// 현재 페이지 번호 가져오기 (기본값은 1)
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;

// LIMIT 절에 사용할 OFFSET 계산
$offset = ($current_page - 1) * $records_per_page;

// 전체 맛집 수 계산
$count_sql = "SELECT COUNT(*) AS total_records FROM mapjip";
$count_result = $conn->query($count_sql);
$total_records = $count_result->fetch_assoc()['total_records'];

// 총 페이지 수 계산
$total_pages = ceil($total_records / $records_per_page);

// SQL 쿼리 작성: mapjip 테이블의 데이터를 최신순으로 가져오고 페이지네이션 적용
// 이미지 경로를 가져오기 위해 image_path 컬럼 추가
// 맛집을 등록한 사용자 ID (user_id)를 가져오기 위해 컬럼 추가
$sql = "SELECT id, name, address, cuisine_type, rating, created_at, image_path, user_id FROM mapjip ORDER BY created_at DESC LIMIT $records_per_page OFFSET $offset";
$result = $conn->query($sql); // 쿼리 실행

?>

<section>
    <h2>오늘의 맛집로그</h2>
    <p>새로운 맛집을 등록하고 공유해 보세요!</p>
    <h3>맛집 목록</h3>
    <?php if ($result->num_rows > 0): // 데이터가 있을 경우 ?>
        <table border="1" style="width:100%; border-collapse:collapse;">
            <thead>
                <tr>
                    <th>맛집 이름</th>
                    <th>주소</th>
                    <th>음식 종류</th>
                    <th>평점</th>
                    <th>등록일</th>
                    <th>맛집사진</th>
                    <th>상세/수정/삭제</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): // 각 행(레코드)을 반복하여 출력 ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['address']) ?></td>
                        <td><?= htmlspecialchars($row['cuisine_type']) ?></td>
                        <td><?= $row['rating'] ?></td>
                        <td><?= substr($row['created_at'], 0, 10) ?></td>
                        <td>
                            <?php if (!empty($row['image_path'])): // 이미지 URL이 있을 경우 ?>
                                <img src="<?= htmlspecialchars($row['image_path']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" style="width: 100px; height: auto; display: block; margin: 0 auto;">
                            <?php else: ?>
                                이미지 없음
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="view.php?id=<?= $row['id'] ?>">상세</a>
                            <?php
                            // 로그인되어 있고, 현재 맛집의 user_id가 세션의 userid와 일치할 경우에만 수정/삭제 링크 표시
                            if (isset($_SESSION['userid']) && $_SESSION['userid'] == $row['user_id']):
                            ?>
                            | <a href="edit_form.php?id=<?= $row['id'] ?>">수정</a>
                            | <a href="delete_process.php?id=<?= $row['id'] ?>&type=mapjip" onclick="return confirm('정말로 삭제하시겠습니까?');">삭제</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div style="text-align: center; margin-top: 20px;">
            <?php if ($current_page > 1): ?>
                <a href="?page=<?= $current_page - 1 ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px;">이전</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?= $i ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px; <?= ($i == $current_page) ? 'background-color: #007bff; color: white;' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($current_page < $total_pages): ?>
                <a href="?page=<?= $current_page + 1 ?>" style="margin: 0 5px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 5px;">다음</a>
            <?php endif; ?>
        </div>

    <?php else: // 데이터가 없을 경우 ?>
        <p>등록된 맛집이 없습니다. 새로운 맛집을 추가해 보세요!</p>
    <?php endif; ?>
</section>
<?php
$conn->close(); // 데이터베이스 연결 닫기
?>