<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인이 필요한 서비스입니다.');</script>";
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

if (!isset($_GET['id']) || !isset($_GET['type'])) {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>history.back();</script>";
    exit;
}

$id = $_GET['id']; // 삭제할 맛집의 id (INT)
$type = $_GET['type']; // 'mapjip'
$user_db_id = $_SESSION['userid']; // $_SESSION['userid']에 users.id(INT)가 저장되므로 이를 직접 사용

$sql = "";
$redirect_url = "mypage.php"; // 삭제 후 마이페이지로 리다이렉트

switch ($type) {
    case 'mapjip':
        // 해당 맛집이 현재 로그인된 사용자의 것인지 확인
        $check_sql = "SELECT user_id FROM mapjip WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        $result_check = mysqli_stmt_get_result($stmt_check);
        $row_check = mysqli_fetch_assoc($result_check);
        mysqli_stmt_close($stmt_check);

        // $row_check['user_id']와 $user_db_id는 모두 INT이므로 직접 비교
        if (!$row_check || $row_check['user_id'] !== $user_db_id) {
            echo "<script>alert('삭제 권한이 없습니다.');</script>";
            echo "<script>history.back();</script>";
            exit;
        }
        
        // 맛집 삭제 전에 해당 맛집에 연결된 게시물(리뷰) 먼저 삭제 (외래 키 제약 조건 위배 방지)
        $sql_delete_related_posts = "DELETE FROM posts WHERE mapjip_id = ?";
        $stmt_posts = mysqli_prepare($conn, $sql_delete_related_posts);
        mysqli_stmt_bind_param($stmt_posts, "i", $id);
        mysqli_stmt_execute($stmt_posts);
        mysqli_stmt_close($stmt_posts);

        $sql = "DELETE FROM mapjip WHERE id = ?";
        $success_msg = "맛집이 성공적으로 삭제되었습니다.";
        $fail_msg = "맛집 삭제에 실패했습니다.";
        break;
    default:
        echo "<script>alert('유효하지 않은 삭제 요청입니다.');</script>";
        echo "<script>history.back();</script>";
        exit;
}

if (!empty($sql)) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id); // id는 INT이므로 "i"

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('$success_msg');</script>";
        echo "<script>window.location.href='$redirect_url';</script>";
    } else {
        echo "<script>alert('$fail_msg: " . mysqli_error($conn) . "');</script>";
        echo "<script>history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>