<?php
session_start(); // 세션을 시작해야 기존 세션에 접근하여 파괴할 수 있습니다.

// 모든 세션 변수 삭제
$_SESSION = array();

// 세션 쿠키 삭제 (브라우저에 저장된 세션 ID 쿠키 제거)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 세션 자체를 파괴
session_destroy();

// 로그아웃 알림 후 홈 페이지로 리다이렉트
echo "<script>alert('로그아웃 되었습니다.');</script>";
echo "<script>window.location.href = 'index.php';</script>";
exit();
?>