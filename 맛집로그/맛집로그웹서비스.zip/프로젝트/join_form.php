<?php

include_once "header.php";
?>
<section>
    <h2>회원가입</h2>
    <form action="join_process.php" method="POST">
        <div>
            <label for="username">아이디 (로그인 ID):</label>
            <input type="text" id="username" name="username" required minlength="4" maxlength="20">
        </div>
        <div>
            <label for="password">비밀번호:</label>
            <input type="password" id="password" name="password" required minlength="6">
        </div>
        <div>
            <label for="password_confirm">비밀번호 확인:</label>
            <input type="password" id="password_confirm" name="password_confirm" required>
        </div>
        <div>
            <label for="email">이메일:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="nickname">닉네임:</label>
            <input type="text" id="nickname" name="nickname" required minlength="2" maxlength="20">
        </div>
        <div class="button-group">
            <input type="submit" value="가입하기">
            <a href="index.php" class="btn" style="background-color: #6c757d;">취소</a>
        </div>
    </form>
</section>

<script>
// 클라이언트 측 비밀번호 일치 확인 
document.querySelector('form').addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;
    const passwordConfirm = document.getElementById('password_confirm').value;

    if (password !== passwordConfirm) {
        alert('비밀번호와 비밀번호 확인이 일치하지 않습니다.');
        e.preventDefault(); // 폼 제출 방지
    }
});
</script>

<?php

include_once "footer.php";
?>