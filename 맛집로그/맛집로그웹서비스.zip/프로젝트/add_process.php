<?php
session_start();
include_once "db_connect.php";

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

$user_id = $_SESSION['userid'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $cuisine_type = trim($_POST['cuisine_type']);
    $phone_number = trim($_POST['phone_number']);
    $rating = (float)$_POST['rating']; // float 캐스팅
    $opening_hours = trim($_POST['opening_hours']);
    $description = trim($_POST['description']);

    $image_path = null;

    // 이미지 업로드 처리
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_file = $upload_dir . $file_name;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        $check = getimagesize($_FILES['image']['tmp_name']);
        if($check !== false) {
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "<script>alert('죄송합니다, JPG, JPEG, PNG, GIF 파일만 허용됩니다.');</script>";
                echo "<script>history.back();</script>";
                exit();
            }
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            } else {
                echo "<script>alert('파일 업로드 중 오류가 발생했습니다.');</script>";
                echo "<script>history.back();</script>";
                exit();
            }
        } else {
            echo "<script>alert('업로드된 파일이 이미지가 아닙니다.');</script>";
            echo "<script>history.back();</script>";
            exit();
        }
    }

    // 데이터베이스에 맛집 정보 삽입: 'mapjip' 테이블 사용
    $sql = "INSERT INTO mapjip (user_id, name, address, cuisine_type, phone_number, rating, opening_hours, description, image_path, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
    $stmt = $conn->prepare($sql);

    if ($stmt === FALSE) {
        die("맛집 추가 SQL 준비 오류: " . $conn->error);
    }

    
    // user_id(int), name(string), address(string), cuisine_type(string), phone_number(string),
    // rating(double), opening_hours(string), description(string), image_path(string)
    $stmt->bind_param("isssdssss",
        $user_id,
        $name,
        $address,
        $cuisine_type,
        $phone_number,
        $rating, // double
        $opening_hours,
        $description,
        $image_path // string (can be null)
    );

    if ($stmt->execute()) {
        echo "<script>alert('맛집 정보가 성공적으로 추가되었습니다!');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
    } else {
        echo "<script>alert('맛집 추가 중 오류가 발생했습니다: " . $stmt->error . "');</script>";
        echo "<script>history.back();</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('잘못된 접근입니다.');</script>";
    echo "<script>window.location.href = 'add_form.php';</script>";
}

$conn->close();
?>