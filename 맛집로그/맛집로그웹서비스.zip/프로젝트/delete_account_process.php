<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['userid'])) {
    echo "<script>alert('로그인이 필요한 서비스입니다.');</script>";
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

// $_SESSION['userid']에 users 테이블의 id(INT)가 저장되므로 이를 직접 사용
$user_db_id = $_SESSION['userid'];

// ----------------------------------------------------------------------
// 보안 강화: 비밀번호 재확인 폼 (선택 사항이지만 강력 권장)
// 실제 운영 환경에서는 회원 탈퇴 전에 현재 비밀번호를 다시 입력받아 확인하는 것이 안전합니다.
// 이 코드는 바로 삭제를 진행합니다.
// ----------------------------------------------------------------------

mysqli_begin_transaction($conn);
$success = true;

try {
    // 1. 해당 사용자가 작성한 게시물(리뷰) 삭제 (posts 테이블)
    $sql_delete_posts = "DELETE FROM posts WHERE user_id = ?";
    $stmt_posts = mysqli_prepare($conn, $sql_delete_posts);
    mysqli_stmt_bind_param($stmt_posts, "i", $user_db_id); // user_id는 INT
    if (!mysqli_stmt_execute($stmt_posts)) {
        throw new Exception("게시물(리뷰) 삭제 실패: " . mysqli_error($conn));
    }
    mysqli_stmt_close($stmt_posts);

    // 2. 해당 사용자가 등록한 맛집 삭제 (mapjip 테이블)
    $sql_delete_mapjips = "DELETE FROM mapjip WHERE user_id = ?";
    $stmt_mapjips = mysqli_prepare($conn, $sql_delete_mapjips);
    mysqli_stmt_bind_param($stmt_mapjips, "i", $user_db_id); // user_id는 INT
    if (!mysqli_stmt_execute($stmt_mapjips)) {
        throw new Exception("맛집 삭제 실패: " . mysqli_error($conn));
    }
    mysqli_stmt_close($stmt_mapjips);

    // 3. 사용자 계정 삭제 (users 테이블) - 가장 마지막에
    $sql_delete_user = "DELETE FROM users WHERE id = ?";
    $stmt_user = mysqli_prepare($conn, $sql_delete_user);
    mysqli_stmt_bind_param($stmt_user, "i", $user_db_id); // id는 INT
    if (!mysqli_stmt_execute($stmt_user)) {
        throw new Exception("계정 삭제 실패: " . mysqli_error($conn));
    }
    mysqli_stmt_close($stmt_user);

    mysqli_commit($conn); // 모든 작업 성공 시 커밋

    // 세션 파괴 및 로그아웃 처리
    session_unset();
    session_destroy();

    echo "<script>alert('회원 탈퇴가 성공적으로 완료되었습니다. 안녕히 가세요.');</script>";
    echo "<script>window.location.href='index.php';</script>"; // 메인 페이지로 리다이렉트
    exit;

} catch (Exception $e) {
    mysqli_rollback($conn); // 실패 시 롤백
    echo "<script>alert('회원 탈퇴 중 오류가 발생했습니다: " . $e->getMessage() . "');</script>";
    echo "<script>window.location.href='mypage.php';</script>";
    exit;
} finally {
    mysqli_close($conn);
}
?>